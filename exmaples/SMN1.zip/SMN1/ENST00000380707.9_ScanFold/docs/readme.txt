These RNA Transcripts were retrieved from https://www.structurome.bb.iastate.edu/azt/.

You can also get the Moss Lab RNA-Annotator Pipeline at https://github.com/moss-lab/RNA-Annotator-v1

